﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyTheThao.Models;

namespace QuanLyTheThao.Data
{
    public class DataAccess
    {
        // Chuỗi kết nối chuẩn
        private string strCon = @"Data Source=DESKTOP-M97IEDH\SQLEXPRESS01;Initial Catalog=QuanLyTheThao;Integrated Security=True";

        public SqlConnection GetConnection()
        {
            return new SqlConnection(strCon);
        }

        // =============================================================
        // 1. XÁC THỰC (AUTH)
        // =============================================================

        public NguoiDung CheckLogin(string u, string p)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                // Chỉ đăng nhập được nếu tài khoản KHÔNG bị khóa (IsLocked = 0 hoặc NULL)
                string q = "SELECT * FROM NguoiDung WHERE TaiKhoan = @u AND MatKhau = @p AND (IsLocked = 0 OR IsLocked IS NULL)";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@u", u);
                cmd.Parameters.AddWithValue("@p", p);

                using (var r = cmd.ExecuteReader())
                {
                    if (r.Read())
                    {
                        return new NguoiDung
                        {
                            Id = (int)r["Id"],
                            TaiKhoan = r["TaiKhoan"].ToString(),
                            HoTen = r["HoTen"].ToString(),
                            VaiTro = r["VaiTro"].ToString(),
                            DiaChi = r["DiaChi"].ToString()
                        };
                    }
                }
            }
            return null;
        }

        public bool Register(string u, string p, string ten, string dc)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    string check = "SELECT COUNT(*) FROM NguoiDung WHERE TaiKhoan = @u";
                    SqlCommand cmdCheck = new SqlCommand(check, conn);
                    cmdCheck.Parameters.AddWithValue("@u", u);
                    if ((int)cmdCheck.ExecuteScalar() > 0) return false;

                    string q = "INSERT INTO NguoiDung (TaiKhoan, MatKhau, HoTen, DiaChi, VaiTro, IsLocked) VALUES (@u, @p, @n, @d, 'User', 0)";
                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@u", u);
                    cmd.Parameters.AddWithValue("@p", p);
                    cmd.Parameters.AddWithValue("@n", ten);
                    cmd.Parameters.AddWithValue("@d", dc);
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch { return false; }
        }

        // =============================================================
        // 2. QUẢN LÝ NGƯỜI DÙNG (USER MANAGEMENT)
        // =============================================================

        public DataTable GetNguoiDungs(string kw = "")
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                // Lấy thêm cột IsLocked
                string q = "SELECT Id, TaiKhoan, MatKhau, HoTen, DiaChi, SoDienThoai, VaiTro, IsLocked FROM NguoiDung WHERE TaiKhoan LIKE @k OR HoTen LIKE @k";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@k", "%" + kw + "%");
                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }

        public void AddUser(NguoiDung u)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = "INSERT INTO NguoiDung (TaiKhoan, MatKhau, HoTen, DiaChi, VaiTro, IsLocked) VALUES (@u, @p, @n, @d, @r, 0)";
                SqlCommand cmd = new SqlCommand(q, conn);
                SetupUserParams(cmd, u);
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateUser(NguoiDung u)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = "UPDATE NguoiDung SET MatKhau=@p, HoTen=@n, DiaChi=@d, VaiTro=@r WHERE Id=@id";
                SqlCommand cmd = new SqlCommand(q, conn);
                SetupUserParams(cmd, u);
                cmd.Parameters.AddWithValue("@id", u.Id);
                cmd.ExecuteNonQuery();
            }
        }
        public DataTable GetLichSuMuaHang(int userId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = @"SELECT MaHD, NgayDat, TongTien, TrangThai, DiaChiGiao 
                     FROM HoaDon 
                     WHERE NguoiMua = @uid 
                     ORDER BY NgayDat DESC";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@uid", userId);

                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }
        public void DeleteUser(int id)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                new SqlCommand("DELETE FROM NguoiDung WHERE Id=" + id, conn).ExecuteNonQuery();
            }
        }

        // Hàm Khóa / Mở Khóa Tài Khoản
        public void ToggleLockUser(int id, bool lockStatus)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = "UPDATE NguoiDung SET IsLocked = @s WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@s", lockStatus);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
        }

        private void SetupUserParams(SqlCommand cmd, NguoiDung u)
        {
            cmd.Parameters.AddWithValue("@u", u.TaiKhoan);
            cmd.Parameters.AddWithValue("@p", u.MatKhau);
            cmd.Parameters.AddWithValue("@n", u.HoTen);
            cmd.Parameters.AddWithValue("@d", u.DiaChi ?? "");
            cmd.Parameters.AddWithValue("@r", u.VaiTro);
        }

        // =============================================================
        // 3. QUẢN LÝ SẢN PHẨM (PRODUCT)
        // =============================================================

        public DataTable GetSanPhams(string kw = "")
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = @"SELECT sp.MaSP, sp.TenSP, sp.GiaBan, sp.SoLuongTon, sp.MoTa, sp.HinhAnh, dm.TenDM, sp.MaDM 
                             FROM SanPham sp LEFT JOIN DanhMuc dm ON sp.MaDM = dm.MaDM 
                             WHERE sp.TenSP LIKE @k OR dm.TenDM LIKE @k";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@k", "%" + kw + "%");
                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }

        public DataTable GetDanhMucs()
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                DataTable dt = new DataTable();
                new SqlDataAdapter("SELECT * FROM DanhMuc", conn).Fill(dt);
                return dt;
            }
        }

        public void AddSanPham(SanPham sp)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = "INSERT INTO SanPham (TenSP, MaDM, GiaBan, SoLuongTon, MoTa, HinhAnh) VALUES (@n, @d, @g, @s, @m, @img)";
                SqlCommand cmd = new SqlCommand(q, conn);
                SetupSP(cmd, sp);
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateSanPham(SanPham sp)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = "UPDATE SanPham SET TenSP=@n, MaDM=@d, GiaBan=@g, SoLuongTon=@s, MoTa=@m, HinhAnh=@img WHERE MaSP=@id";
                SqlCommand cmd = new SqlCommand(q, conn);
                SetupSP(cmd, sp);
                cmd.Parameters.AddWithValue("@id", sp.MaSP);
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteSanPham(int id)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                new SqlCommand("DELETE FROM SanPham WHERE MaSP=" + id, conn).ExecuteNonQuery();
            }
        }

        private void SetupSP(SqlCommand cmd, SanPham sp)
        {
            cmd.Parameters.AddWithValue("@n", sp.TenSP);
            cmd.Parameters.AddWithValue("@d", sp.MaDM);
            cmd.Parameters.AddWithValue("@g", sp.GiaBan);
            cmd.Parameters.AddWithValue("@s", sp.SoLuongTon);
            cmd.Parameters.AddWithValue("@m", sp.MoTa ?? "");
            cmd.Parameters.AddWithValue("@img", sp.HinhAnh ?? "");
        }

        // =============================================================
        // 4. QUẢN LÝ ĐƠN HÀNG (ORDER & INVOICE)
        // =============================================================

        public void TaoDonHang(int userId, decimal tongTien, string diaChi, List<SanPham> gioHang)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                // 1. Tạo Hóa Đơn
                string qHD = "INSERT INTO HoaDon (NguoiMua, NgayDat, TongTien, TrangThai, DiaChiGiao) OUTPUT INSERTED.MaHD VALUES (@u, GETDATE(), @t, N'Chờ Duyệt', @d)";
                SqlCommand cmdHD = new SqlCommand(qHD, conn);
                cmdHD.Parameters.AddWithValue("@u", userId);
                cmdHD.Parameters.AddWithValue("@t", tongTien);
                cmdHD.Parameters.AddWithValue("@d", diaChi);
                int maHD = (int)cmdHD.ExecuteScalar();

                // 2. Tạo Chi Tiết
                foreach (var sp in gioHang)
                {
                    string qCT = "INSERT INTO ChiTietHoaDon (MaHD, MaSP, SoLuong, DonGia, ThanhTien) VALUES (@hd, @sp, 1, @gia, @thanh)";
                    SqlCommand cmdCT = new SqlCommand(qCT, conn);
                    cmdCT.Parameters.AddWithValue("@hd", maHD);
                    cmdCT.Parameters.AddWithValue("@sp", sp.MaSP);
                    cmdCT.Parameters.AddWithValue("@gia", sp.GiaBan);
                    cmdCT.Parameters.AddWithValue("@thanh", sp.GiaBan);
                    cmdCT.ExecuteNonQuery();
                }
            }
        }

        public DataTable GetHoaDons(DateTime from, DateTime to, string status = "All")
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = @"SELECT h.MaHD, h.NgayDat, nd.HoTen, h.TongTien, h.TrangThai, h.DiaChiGiao 
                             FROM HoaDon h JOIN NguoiDung nd ON h.NguoiMua = nd.Id
                             WHERE (h.NgayDat BETWEEN @f AND @t)";

                if (status != "All") q += " AND h.TrangThai = @st";

                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@f", from.Date);
                cmd.Parameters.AddWithValue("@t", to.Date.AddDays(1).AddSeconds(-1));
                if (status != "All") cmd.Parameters.AddWithValue("@st", status);

                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }

        public DataTable GetChiTietHD(int maHD)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = @"SELECT sp.TenSP, ct.SoLuong, ct.DonGia, ct.ThanhTien 
                             FROM ChiTietHoaDon ct JOIN SanPham sp ON ct.MaSP = sp.MaSP
                             WHERE ct.MaHD = @id";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@id", maHD);
                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }

        public void UpdateTrangThaiHD(int maHD, string status)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("UPDATE HoaDon SET TrangThai = @st WHERE MaHD = @id", conn);
                cmd.Parameters.AddWithValue("@st", status);
                cmd.Parameters.AddWithValue("@id", maHD);
                cmd.ExecuteNonQuery();
            }
        }
        // --- CÁC HÀM XỬ LÝ GIỎ HÀNG (LƯU DATABASE) ---

        // 1. Thêm vào giỏ (Nếu có rồi thì tăng số lượng)
        public void ThemVaoGioDB(int userId, int maSP, int soLuong)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                // Kiểm tra xem món này đã có trong giỏ chưa
                var cmdCheck = new SqlCommand("SELECT COUNT(*) FROM GioHang WHERE MaNguoiDung=@u AND MaSP=@p", conn);
                cmdCheck.Parameters.AddWithValue("@u", userId);
                cmdCheck.Parameters.AddWithValue("@p", maSP);
                int count = (int)cmdCheck.ExecuteScalar();

                if (count > 0)
                {
                    // Có rồi -> Cộng dồn số lượng
                    var cmdUp = new SqlCommand("UPDATE GioHang SET SoLuong = SoLuong + @sl WHERE MaNguoiDung=@u AND MaSP=@p", conn);
                    cmdUp.Parameters.AddWithValue("@sl", soLuong);
                    cmdUp.Parameters.AddWithValue("@u", userId);
                    cmdUp.Parameters.AddWithValue("@p", maSP);
                    cmdUp.ExecuteNonQuery();
                }
                else
                {
                    // Chưa có -> Thêm mới
                    var cmdIn = new SqlCommand("INSERT INTO GioHang(MaNguoiDung, MaSP, SoLuong) VALUES(@u, @p, @sl)", conn);
                    cmdIn.Parameters.AddWithValue("@u", userId);
                    cmdIn.Parameters.AddWithValue("@p", maSP);
                    cmdIn.Parameters.AddWithValue("@sl", soLuong);
                    cmdIn.ExecuteNonQuery();
                }
            }
        }

        // 2. Lấy giỏ hàng từ DB lên (Dùng khi Đăng nhập)
        public List<SanPham> LayGioHangDB(int userId)
        {
            List<SanPham> list = new List<SanPham>();
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = @"SELECT sp.*, gh.SoLuong 
                     FROM GioHang gh 
                     JOIN SanPham sp ON gh.MaSP = sp.MaSP 
                     WHERE gh.MaNguoiDung = @u";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@u", userId);

                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        // Vì cấu trúc cũ của bạn là List<SanPham> (mỗi item là 1 món), 
                        // nên nếu SoLuong=5 ta phải add 5 lần object đó vào list
                        int sl = (int)r["SoLuong"];
                        SanPham sp = new SanPham
                        {
                            MaSP = (int)r["MaSP"],
                            TenSP = r["TenSP"].ToString(),
                            GiaBan = Convert.ToDecimal(r["GiaBan"]),
                            HinhAnh = r["HinhAnh"]?.ToString(),
                            // Các trường khác nếu cần...
                        };

                        for (int i = 0; i < sl; i++) list.Add(sp);
                    }
                }
            }
            return list;
        }

        // 3. Xóa 1 món khỏi giỏ (Khi user xóa trong form Giỏ hàng)
        public void XoaKhoiGioDB(int userId, int maSP)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                // Giảm số lượng đi 1, nếu về 0 thì xóa luôn
                // Logic đơn giản cho project này: Xóa luôn dòng đó rồi add lại list mới sau
                // Hoặc đơn giản nhất: Xóa hẳn dòng sản phẩm đó khỏi giỏ
                new SqlCommand($"DELETE FROM GioHang WHERE MaNguoiDung={userId} AND MaSP={maSP}", conn).ExecuteNonQuery();
            }
        }

        // 4. Xóa sạch giỏ (Khi thanh toán xong)
        public void XoaSachGioDB(int userId)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                new SqlCommand($"DELETE FROM GioHang WHERE MaNguoiDung={userId}", conn).ExecuteNonQuery();
            }
        }

        // =============================================================
        // 5. BÁO CÁO (REPORT)
        // =============================================================

        public DataTable GetDoanhThu(DateTime from, DateTime to)
        {
            using (var conn = GetConnection())
            {
                conn.Open();
                string q = @"SELECT h.MaHD, h.NgayDat, nd.HoTen AS KhachHang, h.TongTien, h.TrangThai 
                             FROM HoaDon h JOIN NguoiDung nd ON h.NguoiMua = nd.Id
                             WHERE h.NgayDat BETWEEN @f AND @t AND h.TrangThai != N'Hủy'";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@f", from.Date);
                cmd.Parameters.AddWithValue("@t", to.Date.AddDays(1).AddSeconds(-1));
                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }
    }
}