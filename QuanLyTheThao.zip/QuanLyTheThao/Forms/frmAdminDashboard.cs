﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyTheThao.Utils;

namespace QuanLyTheThao.Forms
{
    public partial class frmAdminDashboard : Form
    {
        public frmAdminDashboard() { InitializeComponent_CodeFirst(); }

        private void InitializeComponent_CodeFirst()
        {
            this.Text = "ADMIN DASHBOARD - SPORTS STORE";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.WhiteSmoke;

            // Header
            Label lblHeader = new Label
            {
                Text = $"QUẢN TRỊ VIÊN: {Session.User?.HoTen.ToUpper()}",
                Dock = DockStyle.Top,
                Height = 70,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 16, FontStyle.Bold),
                BackColor = Color.Navy,
                ForeColor = Color.White
            };

            // Container lưới 2 cột, 2 dòng cho các nút
            TableLayoutPanel table = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 3, Padding = new Padding(50) };
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 33));

            // Thêm nút
            table.Controls.Add(CreateBtn("📦 QUẢN LÝ SẢN PHẨM", Color.Teal, () => new frmSanpham().ShowDialog()), 0, 0);
            table.Controls.Add(CreateBtn("👥 QUẢN LÝ TÀI KHOẢN", Color.Purple, () => new frmTaiKhoan().ShowDialog()), 1, 0);
            table.Controls.Add(CreateBtn("🧾 QUẢN LÝ HÓA ĐƠN", Color.SeaGreen, () => new frmHoaDon().ShowDialog()), 0, 1);
            table.Controls.Add(CreateBtn("📊 BÁO CÁO DOANH THU", Color.Orange, () => new frmBaoCaoDoanhThu().ShowDialog()), 1, 1);

            // Nút đăng xuất (Full chiều ngang ở dưới)
            Button btnOut = CreateBtn("ĐĂNG XUẤT", Color.Firebrick, () => this.Close());
            table.Controls.Add(btnOut, 0, 2);
            table.SetColumnSpan(btnOut, 2); // Gộp 2 cột

            this.Controls.Add(table);
            this.Controls.Add(lblHeader);
            lblHeader.BringToFront();
        }

        private Button CreateBtn(string text, Color c, Action act)
        {
            Button btn = new Button
            {
                Text = text,
                Dock = DockStyle.Fill,
                BackColor = c,
                ForeColor = Color.White,
                Font = new Font("Arial", 12, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Margin = new Padding(10)
            };
            btn.Click += (s, e) => { this.Hide(); act(); this.Show(); };
            return btn;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // frmAdminDashboard
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "frmAdminDashboard";
            this.Load += new System.EventHandler(this.frmAdminDashboard_Load);
            this.ResumeLayout(false);

        }

        private void frmAdminDashboard_Load(object sender, EventArgs e)
        {

        }
    }
}