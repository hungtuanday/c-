﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Utils;

namespace QuanLyTheThao.Forms
{
    public class frmBaoCaoDoanhThu : Form
    {
        private DataAccess db;
        private DataGridView dgv;
        private DateTimePicker dt1, dt2;
        private Label lblTotal;

        public frmBaoCaoDoanhThu()
        {
            db = new DataAccess();
            InitUI();
        }

        private void InitUI()
        {
            this.Text = "BÁO CÁO DOANH THU";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // 1. TOP PANEL
            Panel pnlTop = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Color.WhiteSmoke };

            Label l1 = new Label { Text = "Từ:", Location = new Point(20, 25), AutoSize = true };
            dt1 = new DateTimePicker { Format = DateTimePickerFormat.Short, Location = new Point(50, 22), Width = 110 };

            Label l2 = new Label { Text = "Đến:", Location = new Point(170, 25), AutoSize = true };
            dt2 = new DateTimePicker { Format = DateTimePickerFormat.Short, Location = new Point(210, 22), Width = 110 };

            Button btnView = new Button { Text = "XEM", Location = new Point(340, 20), Width = 100, Height = 30, BackColor = Color.Teal, ForeColor = Color.White };
            btnView.Click += (s, e) => LoadData();

            Button btnExcel = new Button { Text = "EXCEL", Location = new Point(450, 20), Width = 100, Height = 30, BackColor = Color.Green, ForeColor = Color.White };
            btnExcel.Click += (s, e) => ExcelHelper.ExportToExcel(dgv, "BaoCao");

            lblTotal = new Label { Text = "TỔNG: 0 đ", Location = new Point(600, 23), AutoSize = true, Font = new Font("Arial", 14, FontStyle.Bold), ForeColor = Color.Red };

            pnlTop.Controls.Add(l1); pnlTop.Controls.Add(dt1);
            pnlTop.Controls.Add(l2); pnlTop.Controls.Add(dt2);
            pnlTop.Controls.Add(btnView); pnlTop.Controls.Add(btnExcel); pnlTop.Controls.Add(lblTotal);

            // 2. GRID
            dgv = new DataGridView { Dock = DockStyle.Fill, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true, BackgroundColor = Color.White };

            // 3. THỨ TỰ ADD & Z-ORDER (QUAN TRỌNG NHẤT)
            this.Controls.Add(dgv);     // Add Grid
            this.Controls.Add(pnlTop);  // Add Top

            // --- FIX LỖI CHE: ---
            pnlTop.SendToBack();    // Đẩy Top ra sau cùng -> Nó sẽ được ưu tiên cắt màn hình trước
            dgv.BringToFront();     // Đẩy Grid lên trước -> Nó sẽ lấp đầy phần còn lại
        }

        private void LoadData()
        {
            var dt = db.GetDoanhThu(dt1.Value, dt2.Value);
            dgv.DataSource = dt;
            if (dgv.Columns.Contains("TongTien")) dgv.Columns["TongTien"].DefaultCellStyle.Format = "N0";
            decimal sum = 0;
            foreach (System.Data.DataRow r in dt.Rows) sum += Convert.ToDecimal(r["TongTien"]);
            lblTotal.Text = $"TỔNG: {sum:N0} VNĐ";
        }
    }
}