﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Models;
using QuanLyTheThao.Utils;

namespace QuanLyTheThao.Forms
{
    public partial class frmClient : Form
    {
        private DataAccess db;
        private DataGridView dgv;
        private TextBox txtSearch;

        // Controls
        private NumericUpDown numSL;
        private Label lblSelectedSP;
        private Button btnCartInfo;

        // Temp vars
        private int selectedId = -1;
        private string selectedName = "";
        private decimal selectedPrice = 0;

        public frmClient()
        {
            db = new DataAccess();
            InitializeComponent_CodeFirst();
            LoadData();
        }

        private void InitializeComponent_CodeFirst()
        {
            this.Text = $"MUA SẮM TRỰC TUYẾN - Xin chào: {Session.User?.HoTen}";
            this.Size = new Size(1100, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            // --- LAYOUT CHÍNH: TABLE LAYOUT PANEL ---
            TableLayoutPanel mainLayout = new TableLayoutPanel();
            mainLayout.Dock = DockStyle.Fill;
            mainLayout.ColumnCount = 1;
            mainLayout.RowCount = 3;
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70F)); // Top
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F)); // Grid
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F)); // Bot
            this.Controls.Add(mainLayout);

            // 1. TOP PANEL
            Panel pnlTop = new Panel { Dock = DockStyle.Fill, BackColor = Color.WhiteSmoke };

            Label lblSearch = new Label { Text = "Tìm sản phẩm:", Location = new Point(20, 25), AutoSize = true, Font = new Font("Arial", 10) };
            txtSearch = new TextBox { Location = new Point(130, 22), Width = 350, Font = new Font("Arial", 12) };
            txtSearch.TextChanged += (s, e) => LoadData(txtSearch.Text);

            Button btnHistory = new Button
            {
                Text = "📜 LỊCH SỬ ĐƠN",
                Location = new Point(500, 20),
                Width = 140,
                Height = 32,
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                Font = new Font("Arial", 9, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnHistory.Click += (s, e) => new frmLichSu().ShowDialog();

            btnCartInfo = new Button
            {
                Text = $"GIỎ ({Session.Cart.Count})",
                Location = new Point(900, 15),
                Width = 150,
                Height = 40,
                BackColor = Color.Orange,
                ForeColor = Color.White,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            btnCartInfo.Click += BtnCartInfo_Click;

            pnlTop.Controls.Add(lblSearch); pnlTop.Controls.Add(txtSearch);
            pnlTop.Controls.Add(btnHistory); pnlTop.Controls.Add(btnCartInfo);
            mainLayout.Controls.Add(pnlTop, 0, 0);

            // 2. GRID
            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                RowTemplate = { Height = 80 },
                AllowUserToAddRows = false
            };
            dgv.CellClick += Dgv_CellClick;
            dgv.CellFormatting += Dgv_CellFormatting;
            mainLayout.Controls.Add(dgv, 0, 1);

            // 3. BOTTOM PANEL
            Panel pnlBot = new Panel { Dock = DockStyle.Fill, BackColor = Color.MintCream };

            lblSelectedSP = new Label { Text = "Chưa chọn sản phẩm nào", Location = new Point(20, 15), AutoSize = true, Font = new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), ForeColor = Color.Navy };

            Label lblSL = new Label { Text = "Số lượng:", Location = new Point(20, 50), AutoSize = true, Font = new Font("Arial", 10) };
            numSL = new NumericUpDown { Location = new Point(100, 48), Width = 80, Font = new Font("Arial", 12), Minimum = 1, Maximum = 100, Value = 1, TextAlign = HorizontalAlignment.Center };

            Button btnAdd = new Button
            {
                Text = "🛒 THÊM VÀO GIỎ",
                Location = new Point(200, 42),
                Width = 180,
                Height = 40,
                BackColor = Color.Teal,
                ForeColor = Color.White,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnAdd.Click += BtnAddToCart_Click;

            Button btnViewCart = new Button
            {
                Text = "XEM GIỎ & THANH TOÁN >>",
                Location = new Point(400, 42),
                Width = 250,
                Height = 40,
                BackColor = Color.OrangeRed,
                ForeColor = Color.White,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnViewCart.Click += BtnCartInfo_Click;

            pnlBot.Controls.Add(lblSelectedSP); pnlBot.Controls.Add(lblSL);
            pnlBot.Controls.Add(numSL); pnlBot.Controls.Add(btnAdd); pnlBot.Controls.Add(btnViewCart);

            mainLayout.Controls.Add(pnlBot, 0, 2);
        }

        private void LoadData(string k = "")
        {
            var dt = db.GetSanPhams(k);
            dgv.DataSource = dt;

            if (!dgv.Columns.Contains("ImgCol"))
            {
                DataGridViewImageColumn imgCol = new DataGridViewImageColumn { Name = "ImgCol", HeaderText = "Ảnh", ImageLayout = DataGridViewImageCellLayout.Zoom, Width = 100 };
                dgv.Columns.Insert(0, imgCol);
            }

            string[] hideCols = { "MaDM", "MaSP", "HinhAnh", "MoTa", "SoLuongTon" };
            foreach (var col in hideCols) if (dgv.Columns.Contains(col)) dgv.Columns[col].Visible = false;

            if (dgv.Columns.Contains("GiaBan")) dgv.Columns["GiaBan"].DefaultCellStyle.Format = "N0";
        }

        private void Dgv_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgv.Columns[e.ColumnIndex].Name == "ImgCol" && e.RowIndex >= 0)
            {
                string f = dgv.Rows[e.RowIndex].Cells["HinhAnh"].Value?.ToString();
                if (!string.IsNullOrEmpty(f))
                {
                    string p = Path.Combine(Application.StartupPath, "Images", f);
                    if (File.Exists(p)) try { using (Image img = Image.FromFile(p)) { e.Value = new Bitmap(img); } } catch { }
                }
            }
        }

        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var r = dgv.Rows[e.RowIndex];
            selectedId = Convert.ToInt32(r.Cells["MaSP"].Value);
            selectedName = r.Cells["TenSP"].Value.ToString();
            selectedPrice = Convert.ToDecimal(r.Cells["GiaBan"].Value);

            lblSelectedSP.Text = $"Đang chọn: {selectedName} - Giá: {selectedPrice:N0} đ";
            numSL.Value = 1;
        }

        private void BtnAddToCart_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Vui lòng chọn sản phẩm!"); return; }

            int soLuong = (int)numSL.Value;

            // 1. Thêm vào RAM (để hiển thị)
            for (int i = 0; i < soLuong; i++)
            {
                Session.Cart.Add(new SanPham { MaSP = selectedId, TenSP = selectedName, GiaBan = selectedPrice });
            }

            // 2. Thêm vào DB (Lưu vĩnh viễn)
            db.ThemVaoGioDB(Session.User.Id, selectedId, soLuong);

            btnCartInfo.Text = $"GIỎ ({Session.Cart.Count})";
            MessageBox.Show($"Đã thêm {soLuong} sản phẩm vào giỏ!");
        }

        private void BtnCartInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            new frmGioHang().ShowDialog();
            this.Show();
            LoadData();
            btnCartInfo.Text = $"GIỎ ({Session.Cart.Count})";
        }
    }
}