﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Utils;

namespace QuanLyTheThao.Forms
{
    public partial class frmGioHang : Form
    {
        private DataAccess db;
        private DataGridView dgv;
        private Label lblTotal;
        private TextBox txtSearch;

        public frmGioHang()
        {
            db = new DataAccess();
            InitializeComponent_CodeFirst();
            LoadCart();
        }

        private void InitializeComponent_CodeFirst()
        {
            this.Text = "GIỎ HÀNG CỦA BẠN";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            TableLayoutPanel layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Fill;
            layout.ColumnCount = 1;
            layout.RowCount = 3;
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60F));  // Top
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));  // Grid
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 80F));  // Bot
            this.Controls.Add(layout);

            // 1. TOP PANEL
            Panel pnlTop = new Panel { Dock = DockStyle.Fill, BackColor = Color.WhiteSmoke };
            pnlTop.Controls.Add(new Label { Text = "Tìm trong giỏ:", Location = new Point(20, 23), AutoSize = true });
            txtSearch = new TextBox { Location = new Point(120, 20), Width = 300, Font = new Font("Arial", 11) };
            txtSearch.TextChanged += (s, e) => LoadCart(txtSearch.Text);

            Button btnBack = new Button { Text = "<< MUA TIẾP", Location = new Point(850, 15), Width = 100, Height = 35, BackColor = Color.Gray, ForeColor = Color.White };
            btnBack.Click += (s, e) => this.Close();

            pnlTop.Controls.Add(txtSearch); pnlTop.Controls.Add(btnBack);
            layout.Controls.Add(pnlTop, 0, 0);

            // 2. GRID
            dgv = new DataGridView { Dock = DockStyle.Fill, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, BackgroundColor = Color.White };
            layout.Controls.Add(dgv, 0, 1);

            // 3. BOTTOM PANEL
            Panel pnlBot = new Panel { Dock = DockStyle.Fill, BackColor = Color.Gainsboro };
            lblTotal = new Label { Text = "Tổng: 0 đ", Location = new Point(20, 25), AutoSize = true, Font = new Font("Arial", 16, FontStyle.Bold), ForeColor = Color.Red };

            Button btnCheckout = new Button { Text = "THANH TOÁN >>", Location = new Point(700, 15), Width = 200, Height = 50, BackColor = Color.OrangeRed, ForeColor = Color.White, Font = new Font("Arial", 12, FontStyle.Bold), Cursor = Cursors.Hand };
            btnCheckout.Click += (s, e) => {
                if (Session.Cart.Count == 0) { MessageBox.Show("Giỏ trống!"); return; }
                this.Hide(); new frmThanhToan().ShowDialog(); this.Close();
            };

            Button btnDel = new Button { Text = "Xóa món chọn", Location = new Point(300, 25), Width = 120, BackColor = Color.Firebrick, ForeColor = Color.White };
            btnDel.Click += BtnDel_Click;

            pnlBot.Controls.Add(lblTotal); pnlBot.Controls.Add(btnCheckout); pnlBot.Controls.Add(btnDel);
            layout.Controls.Add(pnlBot, 0, 2);
        }

        private void LoadCart(string k = "")
        {
            var displayList = Session.Cart.Where(x => x.TenSP.ToLower().Contains(k.ToLower())).ToList();
            dgv.DataSource = null; dgv.DataSource = displayList;

            string[] hide = { "MaDM", "SoLuongTon", "MoTa", "HinhAnh" };
            foreach (var c in hide) if (dgv.Columns[c] != null) dgv.Columns[c].Visible = false;
            if (dgv.Columns["GiaBan"] != null) dgv.Columns["GiaBan"].DefaultCellStyle.Format = "N0";

            decimal total = 0;
            foreach (var item in Session.Cart) total += item.GiaBan;
            lblTotal.Text = $"TỔNG TIỀN: {total:N0} VNĐ";
        }

        private void BtnDel_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            int idx = dgv.SelectedRows[0].Index;

            if (idx >= 0 && idx < Session.Cart.Count)
            {
                var item = Session.Cart[idx];

                // 1. Xóa trong DB
                db.XoaKhoiGioDB(Session.User.Id, item.MaSP);

                // 2. Xóa trong RAM (Xóa hết các món cùng ID để đồng bộ)
                Session.Cart.RemoveAll(x => x.MaSP == item.MaSP);

                LoadCart();
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // frmGioHang
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "frmGioHang";
            this.Load += new System.EventHandler(this.frmGioHang_Load);
            this.ResumeLayout(false);

        }

        private void frmGioHang_Load(object sender, EventArgs e)
        {

        }
    }
}