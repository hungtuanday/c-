﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Utils; // Nhớ thêm dòng này để dùng ExcelHelper

namespace QuanLyTheThao.Forms
{
    public partial class frmHoaDon : Form
    {
        private DataAccess db;
        private DataGridView dgv;
        private DateTimePicker dt1, dt2;
        private ComboBox cboStatus;

        public frmHoaDon()
        {
            db = new DataAccess();
            InitializeComponent_CodeFirst();
            this.Load += (s, e) => LoadData();
        }

        private void InitializeComponent_CodeFirst()
        {
            this.Text = "QUẢN LÝ HÓA ĐƠN";
            this.Size = new Size(1100, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // 1. TOP PANEL
            Panel pnlTop = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Color.WhiteSmoke };

            // Bộ lọc ngày
            dt1 = new DateTimePicker { Format = DateTimePickerFormat.Short, Location = new Point(20, 25), Width = 100 };
            dt2 = new DateTimePicker { Format = DateTimePickerFormat.Short, Location = new Point(140, 25), Width = 100 };

            // Bộ lọc trạng thái
            cboStatus = new ComboBox { Location = new Point(260, 25), Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
            cboStatus.Items.AddRange(new string[] { "All", "Chờ Duyệt", "Đã Giao", "Hủy" });
            cboStatus.SelectedIndex = 0;

            // Nút Lọc
            Button btnLoc = new Button { Text = "LỌC", Location = new Point(400, 23), BackColor = Color.Navy, ForeColor = Color.White };
            btnLoc.Click += (s, e) => LoadData();

            // Nút Duyệt
            Button btnDuyet = new Button { Text = "DUYỆT", Location = new Point(500, 23), BackColor = Color.Green, ForeColor = Color.White };
            btnDuyet.Click += (s, e) => UpdateStt("Đã Giao");

            // Nút Hủy
            Button btnHuy = new Button { Text = "HỦY", Location = new Point(600, 23), BackColor = Color.Red, ForeColor = Color.White };
            btnHuy.Click += (s, e) => UpdateStt("Hủy");

            // --- NÚT XUẤT EXCEL (MỚI) ---
            Button btnExcel = new Button
            {
                Text = "XUẤT EXCEL",
                Location = new Point(700, 23),
                Width = 100,
                BackColor = Color.ForestGreen,
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            btnExcel.Click += (s, e) => {
                if (dgv.Rows.Count > 0) ExcelHelper.ExportToExcel(dgv, "QuanLyHoaDon");
                else MessageBox.Show("Không có dữ liệu để xuất!");
            };

            pnlTop.Controls.Add(dt1); pnlTop.Controls.Add(dt2); pnlTop.Controls.Add(cboStatus);
            pnlTop.Controls.Add(btnLoc); pnlTop.Controls.Add(btnDuyet); pnlTop.Controls.Add(btnHuy);
            pnlTop.Controls.Add(btnExcel); // Add nút Excel

            // 2. GRID
            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White // Thêm màu nền trắng cho đẹp
            };
            dgv.CellDoubleClick += Dgv_CellDoubleClick;

            // 3. LAYOUT FIX
            this.Controls.Add(dgv);
            this.Controls.Add(pnlTop);

            pnlTop.SendToBack(); // Top ưu tiên cắt cạnh trên
            dgv.BringToFront();  // Grid lấp đầy phần còn lại
        }

        private void LoadData()
        {
            dgv.DataSource = db.GetHoaDons(dt1.Value, dt2.Value, cboStatus.Text);
            // Format cột tiền tệ nếu có
            if (dgv.Columns.Contains("TongTien")) dgv.Columns["TongTien"].DefaultCellStyle.Format = "N0";
        }

        private void UpdateStt(string s)
        {
            if (dgv.SelectedRows.Count == 0) { MessageBox.Show("Vui lòng chọn hóa đơn!"); return; }

            int maHD = (int)dgv.SelectedRows[0].Cells["MaHD"].Value;
            db.UpdateTrangThaiHD(maHD, s);
            LoadData();
            MessageBox.Show($"Đã cập nhật trạng thái thành: {s}");
        }

        private void Dgv_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            int maHD = (int)dgv.Rows[e.RowIndex].Cells["MaHD"].Value;

            Form f = new Form { Size = new Size(700, 450), StartPosition = FormStartPosition.CenterParent, Text = $"CHI TIẾT HÓA ĐƠN #{maHD}" };

            DataGridView g = new DataGridView
            {
                Dock = DockStyle.Fill,
                DataSource = db.GetChiTietHD(maHD),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true
            };

            // Format số tiền trong chi tiết
            if (g.Columns.Contains("DonGia")) g.Columns["DonGia"].DefaultCellStyle.Format = "N0";
            if (g.Columns.Contains("ThanhTien")) g.Columns["ThanhTien"].DefaultCellStyle.Format = "N0";

            f.Controls.Add(g);
            f.ShowDialog();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "frmHoaDon";
            this.Load += new System.EventHandler(this.frmHoaDon_Load);
            this.ResumeLayout(false);
        }

        private void frmHoaDon_Load(object sender, EventArgs e)
        {

        }
    }
}