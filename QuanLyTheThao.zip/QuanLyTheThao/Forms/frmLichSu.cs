﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Utils;

namespace QuanLyTheThao.Forms
{
    public class frmLichSu : Form
    {
        private DataAccess db;
        private DataGridView dgv;

        public frmLichSu()
        {
            db = new DataAccess();
            InitUI();
            LoadData();
        }

        private void InitUI()
        {
            this.Text = "LỊCH SỬ ĐƠN HÀNG CỦA BẠN";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // --- MAIN LAYOUT (3 Dòng) ---
            TableLayoutPanel table = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F)); // Dòng 1: Tiêu đề
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F)); // Dòng 2: Thanh nút bấm (MỚI)
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 100F)); // Dòng 3: Grid
            this.Controls.Add(table);

            // 1. Tiêu đề
            Label lbl = new Label { Text = "DANH SÁCH ĐƠN HÀNG ĐÃ MUA", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Arial", 14, FontStyle.Bold), ForeColor = Color.Navy };
            table.Controls.Add(lbl, 0, 0);

            // 2. PANEL CHỨA NÚT (Dùng FlowLayout để tự căn phải -> KHÔNG BAO GIỜ BỊ CHE)
            FlowLayoutPanel flowBtn = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft, // Các nút sẽ xếp từ phải sang trái
                BackColor = Color.WhiteSmoke,
                Padding = new Padding(10, 5, 10, 5) // Căn lề
            };

            // Nút 1: Xuất Excel (Danh sách)
            Button btnExcelList = new Button
            {
                Text = "XUẤT DANH SÁCH",
                Width = 150,
                Height = 35,
                BackColor = Color.ForestGreen,
                ForeColor = Color.White,
                Font = new Font("Arial", 9, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Margin = new Padding(10, 0, 0, 0)
            };
            btnExcelList.Click += (s, e) => {
                if (dgv.Rows.Count > 0) ExcelHelper.ExportToExcel(dgv, "LichSuMuaHang");
                else MessageBox.Show("Không có dữ liệu!");
            };

            // Nút 2: In Hóa Đơn (Chi tiết đơn đang chọn)
            Button btnPrintBill = new Button
            {
                Text = "🖨 IN HÓA ĐƠN",
                Width = 150,
                Height = 35,
                BackColor = Color.OrangeRed,
                ForeColor = Color.White,
                Font = new Font("Arial", 9, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnPrintBill.Click += BtnPrintBill_Click;

            // Add nút vào Panel (Nút nào add trước sẽ nằm bên phải cùng do RightToLeft)
            flowBtn.Controls.Add(btnExcelList);
            flowBtn.Controls.Add(btnPrintBill);

            table.Controls.Add(flowBtn, 0, 1); // Add Panel nút vào dòng 2

            // 3. Grid
            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White
            };
            dgv.CellDoubleClick += Dgv_CellDoubleClick;
            table.Controls.Add(dgv, 0, 2);

            // Note
            Label lblNote = new Label { Text = "* Click đúp vào dòng để xem chi tiết", Dock = DockStyle.Bottom, AutoSize = true, ForeColor = Color.Gray, Padding = new Padding(10) };
            this.Controls.Add(lblNote);
        }

        private void LoadData()
        {
            dgv.DataSource = db.GetLichSuMuaHang(Session.User.Id);
            if (dgv.Columns.Contains("TongTien")) dgv.Columns["TongTien"].DefaultCellStyle.Format = "N0";
        }

        // Xử lý In Hóa Đơn (Xuất Excel chi tiết đơn hàng đó)
        private void BtnPrintBill_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) { MessageBox.Show("Vui lòng chọn đơn hàng cần in!"); return; }

            int maHD = (int)dgv.SelectedRows[0].Cells["MaHD"].Value;

            // Lấy dữ liệu chi tiết
            var dtDetail = db.GetChiTietHD(maHD);
            if (dtDetail.Rows.Count > 0)
            {
                // Hack: Tạo một GridView tạm để dùng hàm ExportToExcel có sẵn
                DataGridView tempGrid = new DataGridView();
                tempGrid.DataSource = dtDetail;

                ExcelHelper.ExportToExcel(tempGrid, $"HoaDon_{maHD}");

                MessageBox.Show($"Đã xuất hóa đơn #{maHD} thành công!");
            }
            else MessageBox.Show("Hóa đơn này không có sản phẩm!");
        }

        private void Dgv_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            int maHD = (int)dgv.Rows[e.RowIndex].Cells["MaHD"].Value;

            Form f = new Form { Text = $"CHI TIẾT ĐƠN #{maHD}", Size = new Size(600, 400), StartPosition = FormStartPosition.CenterParent };
            DataGridView g = new DataGridView { Dock = DockStyle.Fill, DataSource = db.GetChiTietHD(maHD), AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true };
            if (g.Columns.Contains("DonGia")) g.Columns["DonGia"].DefaultCellStyle.Format = "N0";
            if (g.Columns.Contains("ThanhTien")) g.Columns["ThanhTien"].DefaultCellStyle.Format = "N0";
            f.Controls.Add(g);
            f.ShowDialog();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "frmLichSu";
            this.Load += new System.EventHandler(this.frmLichSu_Load);
            this.ResumeLayout(false);
        }

        private void frmLichSu_Load(object sender, EventArgs e)
        {

        }
    }
}