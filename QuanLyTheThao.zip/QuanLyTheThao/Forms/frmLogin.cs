﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Utils;

namespace QuanLyTheThao.Forms
{
    public partial class frmLogin : Form
    {
        private TextBox txtUser, txtPass;
        private DataAccess db;

        public frmLogin()
        {
            db = new DataAccess();
            InitializeComponent_CodeFirst();
        }

        private void InitializeComponent_CodeFirst()
        {
            this.Size = new Size(400, 350);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "LOGIN SPORT STORE";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            Label lbl = new Label { Text = "ĐĂNG NHẬP", Font = new Font("Arial", 16, FontStyle.Bold), ForeColor = Color.Navy, AutoSize = true, Location = new Point(120, 30) };

            Label l1 = new Label { Text = "Tài khoản:", Location = new Point(50, 80) };
            txtUser = new TextBox { Location = new Point(50, 105), Width = 280, Text = "admin" }; // Default tiện test

            Label l2 = new Label { Text = "Mật khẩu:", Location = new Point(50, 145) };
            txtPass = new TextBox { Location = new Point(50, 170), Width = 280, PasswordChar = '*', Text = "1" }; // Default tiện test

            Button btnLogin = new Button { Text = "VÀO HỆ THỐNG", Location = new Point(50, 220), Width = 280, Height = 40, BackColor = Color.Navy, ForeColor = Color.White, Cursor = Cursors.Hand };
            btnLogin.Click += BtnLogin_Click;

            Button btnReg = new Button { Text = "Đăng ký tài khoản mới", Location = new Point(100, 270), Width = 180, FlatStyle = FlatStyle.Flat, ForeColor = Color.Blue };
            btnReg.FlatAppearance.BorderSize = 0;
            btnReg.Click += (s, e) => { this.Hide(); new frmRegister().ShowDialog(); this.Show(); };

            this.Controls.Add(lbl); this.Controls.Add(l1); this.Controls.Add(txtUser);
            this.Controls.Add(l2); this.Controls.Add(txtPass);
            this.Controls.Add(btnLogin); this.Controls.Add(btnReg);
            this.AcceptButton = btnLogin;
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            var user = db.CheckLogin(txtUser.Text.Trim(), txtPass.Text.Trim());
            if (user != null)
            {
                Session.User = user;

                // --- QUAN TRỌNG: Tải giỏ hàng cũ từ Database lên RAM ---
                Session.Cart = db.LayGioHangDB(user.Id);
                // -------------------------------------------------------

                this.Hide();
                if (user.VaiTro == "Admin") new frmAdminDashboard().ShowDialog();
                else new frmClient().ShowDialog();

                this.Show();
                txtPass.Text = "";
            }
            else MessageBox.Show("Sai tài khoản hoặc mật khẩu (hoặc tài khoản bị khóa)!");
        }
    }
}