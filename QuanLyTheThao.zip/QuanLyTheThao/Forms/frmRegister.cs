﻿    using System;
    using System.Drawing;
    using System.Windows.Forms;
    using QuanLyTheThao.Data;

    namespace QuanLyTheThao.Forms
    {
        public partial class frmRegister : Form
        {
            private DataAccess db;
            private TextBox txtUser, txtPass, txtName, txtAddr;

            public frmRegister()
            {
                db = new DataAccess();
                InitializeComponent_CodeFirst();
            }

            private void InitializeComponent()
            {
                this.SuspendLayout();
                // 
                // frmRegister
                // 
                this.ClientSize = new System.Drawing.Size(282, 253);
                this.Name = "frmRegister";
                this.Load += new System.EventHandler(this.frmRegister_Load);
                this.ResumeLayout(false);

            }

            private void frmRegister_Load(object sender, EventArgs e)
            {

            }

            private void InitializeComponent_CodeFirst()
            {
                this.Size = new Size(400, 450);
                this.StartPosition = FormStartPosition.CenterParent;
                this.Text = "ĐĂNG KÝ";

                int y = 30;
                AddInput("Tài khoản:", ref txtUser, ref y);
                AddInput("Mật khẩu:", ref txtPass, ref y, true);
                AddInput("Họ tên:", ref txtName, ref y);
                AddInput("Địa chỉ:", ref txtAddr, ref y);

                Button btnReg = new Button { Text = "ĐĂNG KÝ NGAY", Location = new Point(50, y + 20), Width = 280, Height = 45, BackColor = Color.Green, ForeColor = Color.White };
                btnReg.Click += BtnReg_Click;

                this.Controls.Add(btnReg);
            }

            private void AddInput(string label, ref TextBox txt, ref int y, bool isPass = false)
            {
                this.Controls.Add(new Label { Text = label, Location = new Point(50, y), AutoSize = true });
                txt = new TextBox { Location = new Point(50, y + 25), Width = 280 };
                if (isPass) txt.PasswordChar = '*';
                this.Controls.Add(txt);
                y += 70;
            }

            private void BtnReg_Click(object sender, EventArgs e)
            {
                if (string.IsNullOrEmpty(txtUser.Text) || string.IsNullOrEmpty(txtPass.Text)) { MessageBox.Show("Nhập đủ thông tin!"); return; }
                if (db.Register(txtUser.Text, txtPass.Text, txtName.Text, txtAddr.Text))
                {
                    MessageBox.Show("Đăng ký thành công!");
                    this.Close();
                }
                else MessageBox.Show("Tài khoản đã tồn tại!");
            }
        }
    }