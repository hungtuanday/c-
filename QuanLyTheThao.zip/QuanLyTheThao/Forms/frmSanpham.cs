﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Models;

namespace QuanLyTheThao.Forms
{
    public partial class frmSanpham : Form
    {
        private DataAccess db;
        private DataGridView dgv;
        private TextBox txtSearch, txtTen, txtGia, txtSL, txtMoTa;
        private ComboBox cboDM;
        private PictureBox picSP;
        private string currentImageName = "";
        private int selectedId = -1;

        public frmSanpham()
        {
            db = new DataAccess();
            InitializeComponent_CodeFirst();
            LoadData();
        }

        private void InitializeComponent_CodeFirst()
        {
            this.Text = "QUẢN LÝ SẢN PHẨM";
            this.Size = new Size(1200, 700);
            this.StartPosition = FormStartPosition.CenterScreen;

            // A. TOP (Tìm kiếm)
            Panel pnlTop = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.WhiteSmoke };
            txtSearch = new TextBox { Location = new Point(120, 20), Width = 400 };
            txtSearch.TextChanged += (s, e) => LoadData(txtSearch.Text);
            pnlTop.Controls.Add(new Label { Text = "Tìm kiếm:", Location = new Point(20, 23), AutoSize = true });
            pnlTop.Controls.Add(txtSearch);

            // B. LEFT (Nhập liệu)
            Panel pnlLeft = new Panel { Dock = DockStyle.Left, Width = 350, BackColor = Color.Gainsboro, Padding = new Padding(10) };

            // Ảnh
            picSP = new PictureBox { Dock = DockStyle.Top, Height = 200, SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
            Button btnUp = new Button { Text = "CHỌN ẢNH", Dock = DockStyle.Top, Height = 30, BackColor = Color.Gray, ForeColor = Color.White };
            btnUp.Click += BtnUpload_Click;

            // Panel chứa các input còn lại
            Panel pnlIn = new Panel { Dock = DockStyle.Fill };
            int y = 10;
            txtTen = AddInput(pnlIn, "Tên SP:", ref y);

            pnlIn.Controls.Add(new Label { Text = "Danh mục:", Location = new Point(10, y) });
            cboDM = new ComboBox { Location = new Point(10, y + 20), Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            cboDM.DataSource = db.GetDanhMucs(); cboDM.DisplayMember = "TenDM"; cboDM.ValueMember = "MaDM";
            pnlIn.Controls.Add(cboDM); y += 50;

            txtGia = AddInput(pnlIn, "Giá:", ref y);
            txtSL = AddInput(pnlIn, "Số lượng:", ref y);
            txtMoTa = AddInput(pnlIn, "Mô tả:", ref y);

            // Nút Thêm/Sửa/Xóa
            Button btnAdd = new Button { Text = "THÊM", Location = new Point(10, y + 10), Width = 80, BackColor = Color.Teal, ForeColor = Color.White };
            Button btnEdit = new Button { Text = "UPDATE", Location = new Point(100, y + 10), Width = 80, BackColor = Color.Orange, ForeColor = Color.White };
            Button btnDel = new Button { Text = "XÓA", Location = new Point(190, y + 10), Width = 80, BackColor = Color.Firebrick, ForeColor = Color.White };

            btnAdd.Click += (s, e) => SaveData("ADD");
            btnEdit.Click += (s, e) => SaveData("EDIT");
            btnDel.Click += (s, e) => SaveData("DEL");

            pnlIn.Controls.Add(btnAdd); pnlIn.Controls.Add(btnEdit); pnlIn.Controls.Add(btnDel);

            pnlLeft.Controls.Add(pnlIn);
            pnlLeft.Controls.Add(btnUp);
            pnlLeft.Controls.Add(picSP);

            // C. GRID
            dgv = new DataGridView { Dock = DockStyle.Fill, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, BackgroundColor = Color.White };
            dgv.CellClick += Dgv_CellClick;

            // D. ADD & FIX LAYOUT (Theo đúng thứ tự này)
            this.Controls.Add(dgv);     // 1. Grid
            this.Controls.Add(pnlTop);  // 2. Top
            this.Controls.Add(pnlLeft); // 3. Left

            // E. ÉP KIỂU Z-ORDER
            pnlTop.SendToBack();   // Top ưu tiên 1 (Cắt cạnh trên)
            pnlLeft.SendToBack();  // Left ưu tiên 2 (Cắt cạnh trái)
            dgv.BringToFront();    // Grid lấp đầy phần còn lại
        }

        private TextBox AddInput(Panel p, string l, ref int y)
        {
            p.Controls.Add(new Label { Text = l, Location = new Point(10, y) });
            TextBox t = new TextBox { Location = new Point(10, y + 20), Width = 300 };
            p.Controls.Add(t); y += 50; return t;
        }

        private void LoadData(string k = "") { dgv.DataSource = db.GetSanPhams(k); }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // frmSanpham
            // 
            this.ClientSize = new System.Drawing.Size(278, 244);
            this.Name = "frmSanpham";
            this.Load += new System.EventHandler(this.frmSanpham_Load);
            this.ResumeLayout(false);

        }

        private void frmSanpham_Load(object sender, EventArgs e)
        {

        }

        private void BtnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog { Filter = "Image|*.jpg;*.png" };
            if (op.ShowDialog() == DialogResult.OK)
            {
                picSP.Image = Image.FromFile(op.FileName);
                picSP.Tag = op.FileName; // Lưu tạm đường dẫn
            }
        }

        private void SaveData(string act)
        {
            if (act == "DEL") { if (selectedId != -1 && MessageBox.Show("Xóa?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes) { db.DeleteSanPham(selectedId); LoadData(); Clear(); } return; }

            // Xử lý ảnh
            string imgName = currentImageName;
            if (picSP.Tag != null)
            {
                string ext = Path.GetExtension(picSP.Tag.ToString());
                imgName = Guid.NewGuid() + ext;
                string dest = Path.Combine(Application.StartupPath, "Images");
                if (!Directory.Exists(dest)) Directory.CreateDirectory(dest);
                File.Copy(picSP.Tag.ToString(), Path.Combine(dest, imgName), true);
            }

            SanPham sp = new SanPham { MaSP = selectedId, TenSP = txtTen.Text, MaDM = (int)cboDM.SelectedValue, GiaBan = decimal.Parse(txtGia.Text), SoLuongTon = int.Parse(txtSL.Text), MoTa = txtMoTa.Text, HinhAnh = imgName };
            if (act == "ADD") db.AddSanPham(sp); else db.UpdateSanPham(sp);
            LoadData(); Clear(); MessageBox.Show("Xong!");
        }

        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var r = dgv.Rows[e.RowIndex];
            selectedId = (int)r.Cells["MaSP"].Value;
            txtTen.Text = r.Cells["TenSP"].Value.ToString();
            txtGia.Text = r.Cells["GiaBan"].Value.ToString();
            txtSL.Text = r.Cells["SoLuongTon"].Value.ToString();
            txtMoTa.Text = r.Cells["MoTa"].Value.ToString();
            cboDM.SelectedValue = r.Cells["MaDM"].Value;

            currentImageName = r.Cells["HinhAnh"].Value?.ToString();
            if (!string.IsNullOrEmpty(currentImageName))
            {
                string p = Path.Combine(Application.StartupPath, "Images", currentImageName);
                if (File.Exists(p)) picSP.Image = Image.FromFile(p); else picSP.Image = null;
            }
            else picSP.Image = null;
            picSP.Tag = null;
        }
        private void Clear() { txtTen.Text = ""; txtGia.Text = ""; txtSL.Text = ""; txtMoTa.Text = ""; picSP.Image = null; picSP.Tag = null; selectedId = -1; currentImageName = ""; }
    }
}