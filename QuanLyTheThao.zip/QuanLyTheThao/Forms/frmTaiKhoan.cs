﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Models;

namespace QuanLyTheThao.Forms
{
    public partial class frmTaiKhoan : Form
    {
        private DataAccess db;
        private DataGridView dgv;
        private TextBox txtSearch, txtUser, txtName, txtAddress, txtPhone;
        private ComboBox cboRole;
        private Button btnLock;

        private int selectedId = -1;
        private bool isCurrentLocked = false;
        private string hiddenPassword = "";

        public frmTaiKhoan()
        {
            db = new DataAccess();
            InitializeComponent_CodeFirst();
            this.Load += (s, e) => LoadData();
        }

        private void InitializeComponent_CodeFirst()
        {
            this.Text = "QUẢN LÝ TÀI KHOẢN (Đã ẩn mật khẩu)";
            this.Size = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            // --- 1. TOP PANEL (Tìm kiếm) ---
            Panel pnlTop = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.WhiteSmoke };

            Label lblSearch = new Label { Text = "Tìm User (Tên/TK):", Location = new Point(20, 23), AutoSize = true, Font = new Font("Arial", 10) };
            txtSearch = new TextBox { Location = new Point(150, 20), Width = 350, Font = new Font("Arial", 11) };
            txtSearch.TextChanged += (s, e) => LoadData(txtSearch.Text);

            pnlTop.Controls.Add(lblSearch);
            pnlTop.Controls.Add(txtSearch);

            // --- 2. BOTTOM PANEL (Nhập liệu & Chức năng) ---
            Panel pnlBot = new Panel { Dock = DockStyle.Bottom, Height = 240, BackColor = Color.WhiteSmoke };

            // Cấu hình chung cho đẹp
            int col1_X = 30;   // Cột trái bắt đầu từ 30
            int col2_X = 450;  // Cột phải bắt đầu từ 450 (Đẩy ra xa để ô nhập bên trái đủ chỗ)
            int inputW = 300;  // Độ rộng chung cho tất cả ô nhập (300px)

            // --- DÒNG 1: Tài khoản & Họ tên ---
            int yRow1 = 20;
            txtUser = AddControl(pnlBot, "Tài khoản:", col1_X, yRow1, inputW);
            txtName = AddControl(pnlBot, "Họ và Tên:", col2_X, yRow1, inputW);

            // --- DÒNG 2: Số điện thoại & Địa chỉ ---
            int yRow2 = 70;
            txtPhone = AddControl(pnlBot, "SĐT:", col1_X, yRow2, inputW);     // Đã set rộng 300
            txtAddress = AddControl(pnlBot, "Địa chỉ:", col2_X, yRow2, inputW); // Đã set rộng 300

            // --- DÒNG 3: Quyền ---
            int yRow3 = 120;
            Label lblRole = new Label { Text = "Quyền:", Location = new Point(col1_X, yRow3 + 4), AutoSize = true, Font = new Font("Arial", 10) };
            cboRole = new ComboBox { Location = new Point(col1_X + 80, yRow3), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Arial", 10), Height = 30 };
            cboRole.Items.AddRange(new string[] { "User", "Admin" });
            cboRole.SelectedIndex = 0;

            Label lblNote = new Label { Text = "(Lưu ý: User mới mặc định mật khẩu là '1')", Location = new Point(col1_X + 300, yRow3 + 4), AutoSize = true, Font = new Font("Arial", 9, FontStyle.Italic), ForeColor = Color.Gray };

            pnlBot.Controls.Add(lblRole); pnlBot.Controls.Add(cboRole); pnlBot.Controls.Add(lblNote);

            // --- DÒNG 4: Buttons ---
            int yBtn = 170;
            // Căn lại vị trí nút cho cân đối với layout mới
            Button btnAdd = CreateBtn("THÊM MỚI", Color.Teal, 30, yBtn);
            btnAdd.Click += BtnAdd_Click;

            Button btnEdit = CreateBtn("CẬP NHẬT", Color.Orange, 160, yBtn);
            btnEdit.Click += BtnEdit_Click;

            Button btnDel = CreateBtn("XÓA", Color.Firebrick, 290, yBtn);
            btnDel.Click += BtnDel_Click;

            btnLock = CreateBtn("KHÓA / MỞ", Color.Gray, 420, yBtn);
            btnLock.Width = 140;
            btnLock.Click += BtnLock_Click;

            Button btnReset = CreateBtn("LÀM MỚI", Color.SteelBlue, 590, yBtn);
            btnReset.Click += (s, e) => ClearInput();

            pnlBot.Controls.Add(btnAdd); pnlBot.Controls.Add(btnEdit);
            pnlBot.Controls.Add(btnDel); pnlBot.Controls.Add(btnLock); pnlBot.Controls.Add(btnReset);

            // --- 3. GRID ---
            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false
            };
            dgv.CellClick += Dgv_CellClick;

            // --- 4. Z-ORDER ---
            this.Controls.Add(dgv);
            this.Controls.Add(pnlTop);
            this.Controls.Add(pnlBot);

            pnlTop.SendToBack();
            pnlBot.SendToBack();
            dgv.BringToFront();
        }

        private TextBox AddControl(Panel p, string labelText, int x, int y, int width)
        {
            Label lbl = new Label { Text = labelText, Location = new Point(x, y + 4), AutoSize = true, Font = new Font("Arial", 10) };
            // Label cách TextBox 80px, nên TextBox bắt đầu từ x + 80
            TextBox txt = new TextBox { Location = new Point(x + 80, y), Width = width, Font = new Font("Arial", 11) };
            p.Controls.Add(lbl); p.Controls.Add(txt);
            return txt;
        }

        private Button CreateBtn(string t, Color c, int x, int y)
        {
            return new Button { Text = t, Location = new Point(x, y), BackColor = c, ForeColor = Color.White, Width = 110, Height = 40, Font = new Font("Arial", 9, FontStyle.Bold), Cursor = Cursors.Hand, FlatStyle = FlatStyle.Flat };
        }

        private void LoadData(string k = "")
        {
            dgv.DataSource = db.GetNguoiDungs(k);
            if (dgv.Columns.Contains("MatKhau")) dgv.Columns["MatKhau"].Visible = false;
        }

        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var r = dgv.Rows[e.RowIndex];

            selectedId = Convert.ToInt32(r.Cells["Id"].Value);
            txtUser.Text = r.Cells["TaiKhoan"].Value.ToString();
            txtName.Text = r.Cells["HoTen"].Value.ToString();

            // Lấy dữ liệu Địa chỉ và SĐT
            txtAddress.Text = r.Cells["DiaChi"].Value?.ToString() ?? "";
            txtPhone.Text = r.Cells["SoDienThoai"].Value?.ToString() ?? "";

            hiddenPassword = r.Cells["MatKhau"].Value?.ToString() ?? "";

            string role = r.Cells["VaiTro"].Value.ToString();
            if (cboRole.Items.Contains(role)) cboRole.SelectedItem = role;

            if (r.Cells["IsLocked"].Value != DBNull.Value)
            {
                isCurrentLocked = (bool)r.Cells["IsLocked"].Value;
                if (isCurrentLocked) { btnLock.Text = "MỞ KHÓA"; btnLock.BackColor = Color.Green; }
                else { btnLock.Text = "KHÓA TK"; btnLock.BackColor = Color.Gray; }
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUser.Text)) return;
            try
            {
                db.AddUser(new NguoiDung
                {
                    TaiKhoan = txtUser.Text,
                    MatKhau = "1",
                    HoTen = txtName.Text,
                    DiaChi = txtAddress.Text,
                    SoDienThoai = txtPhone.Text,
                    VaiTro = cboRole.Text
                });
                LoadData(); MessageBox.Show("Thêm thành công! MK mặc định: '1'"); ClearInput();
            }
            catch (Exception ex) { MessageBox.Show("Lỗi: " + ex.Message); }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) { MessageBox.Show("Chọn tài khoản cần sửa!"); return; }
            try
            {
                db.UpdateUser(new NguoiDung
                {
                    Id = selectedId,
                    TaiKhoan = txtUser.Text,
                    MatKhau = hiddenPassword,
                    HoTen = txtName.Text,
                    DiaChi = txtAddress.Text,
                    SoDienThoai = txtPhone.Text,
                    VaiTro = cboRole.Text
                });
                LoadData(); MessageBox.Show("Cập nhật thành công!"); ClearInput();
            }
            catch (Exception ex) { MessageBox.Show("Lỗi: " + ex.Message); }
        }

        private void BtnDel_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) return;
            if (MessageBox.Show("Xóa tài khoản này?", "Cảnh báo", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                db.DeleteUser(selectedId); LoadData(); ClearInput();
            }
        }

        private void BtnLock_Click(object sender, EventArgs e)
        {
            if (selectedId == -1) return;
            bool newStatus = !isCurrentLocked;
            db.ToggleLockUser(selectedId, newStatus);
            LoadData();
            MessageBox.Show(newStatus ? "Đã KHÓA tài khoản!" : "Đã MỞ KHÓA tài khoản!");
            ClearInput();
        }

        private void ClearInput()
        {
            txtUser.Text = ""; txtName.Text = "";
            txtAddress.Text = ""; txtPhone.Text = "";
            cboRole.SelectedIndex = 0; selectedId = -1;
            btnLock.Text = "KHÓA / MỞ"; btnLock.BackColor = Color.Gray;
            isCurrentLocked = false;
            hiddenPassword = "";
        }
    }
}