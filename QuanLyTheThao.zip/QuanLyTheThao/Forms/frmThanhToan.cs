﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyTheThao.Data;
using QuanLyTheThao.Utils;

namespace QuanLyTheThao.Forms
{
    public partial class frmThanhToan : Form
    {
        private DataAccess db;
        private TextBox txtName, txtPhone, txtAddress, txtSearch;
        private Label lblTotal;

        public frmThanhToan()
        {
            db = new DataAccess();
            InitializeComponent_CodeFirst();
            LoadUserInfo();
        }

        private void InitializeComponent_CodeFirst()
        {
            this.Text = "XÁC NHẬN THANH TOÁN";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            Panel pnlTop = new Panel { Dock = DockStyle.Top, Height = 50, BackColor = Color.WhiteSmoke };
            pnlTop.Controls.Add(new Label { Text = "Tìm kiếm:", Location = new Point(20, 18), AutoSize = true });
            txtSearch = new TextBox { Location = new Point(80, 15), Width = 300, Enabled = false, Text = "Đang ở bước thanh toán..." };
            Button btnBack = new Button { Text = "QUAY LẠI", Location = new Point(650, 10), Width = 100, BackColor = Color.Gray, ForeColor = Color.White };
            btnBack.Click += (s, e) => this.Close();
            pnlTop.Controls.Add(txtSearch); pnlTop.Controls.Add(btnBack);

            Panel pnlMain = new Panel { Dock = DockStyle.Fill, Padding = new Padding(50) };

            int y = 20;
            Label l1 = new Label { Text = "THÔNG TIN GIAO HÀNG", Font = new Font("Arial", 14, FontStyle.Bold), ForeColor = Color.Navy, Location = new Point(50, y), AutoSize = true };
            y += 50;

            txtName = AddInput(pnlMain, "Người nhận:", ref y);
            txtPhone = AddInput(pnlMain, "Số điện thoại:", ref y);
            txtAddress = AddInput(pnlMain, "Địa chỉ giao:", ref y);

            y += 20;
            Label lPay = new Label { Text = "Phương thức thanh toán:", Location = new Point(50, y), AutoSize = true, Font = new Font("Arial", 11, FontStyle.Bold) };
            RadioButton rdoCOD = new RadioButton { Text = "Thanh toán khi nhận hàng (COD)", Location = new Point(50, y + 30), AutoSize = true, Checked = true, Font = new Font("Arial", 11) };
            pnlMain.Controls.Add(lPay); pnlMain.Controls.Add(rdoCOD);

            y += 80;
            decimal total = 0;
            foreach (var item in Session.Cart) total += item.GiaBan;

            Label lSum = new Label { Text = $"Tổng số lượng: {Session.Cart.Count} món", Location = new Point(50, y), AutoSize = true, Font = new Font("Arial", 11) };
            lblTotal = new Label { Text = $"TỔNG THANH TOÁN: {total:N0} VNĐ", Location = new Point(50, y + 30), AutoSize = true, Font = new Font("Arial", 16, FontStyle.Bold), ForeColor = Color.Red };

            pnlMain.Controls.Add(l1); pnlMain.Controls.Add(lSum); pnlMain.Controls.Add(lblTotal);

            Button btnConfirm = new Button { Text = "ĐẶT HÀNG NGAY", Location = new Point(50, y + 80), Width = 300, Height = 50, BackColor = Color.OrangeRed, ForeColor = Color.White, Font = new Font("Arial", 12, FontStyle.Bold), Cursor = Cursors.Hand };
            btnConfirm.Click += BtnConfirm_Click;
            pnlMain.Controls.Add(btnConfirm);

            this.Controls.Add(pnlMain); this.Controls.Add(pnlTop);
            pnlTop.BringToFront();
        }

        private TextBox AddInput(Panel p, string label, ref int y)
        {
            p.Controls.Add(new Label { Text = label, Location = new Point(50, y), AutoSize = true });
            TextBox t = new TextBox { Location = new Point(50, y + 25), Width = 400, Font = new Font("Arial", 11) };
            p.Controls.Add(t); y += 70; return t;
        }

        private void LoadUserInfo()
        {
            if (Session.User != null)
            {
                txtName.Text = Session.User.HoTen;
                txtAddress.Text = Session.User.DiaChi;
                txtPhone.Text = Session.User.SoDienThoai;
            }
        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtAddress.Text) || string.IsNullOrEmpty(txtPhone.Text))
            {
                MessageBox.Show("Vui lòng nhập địa chỉ và SĐT!"); return;
            }

            decimal total = 0;
            foreach (var item in Session.Cart) total += item.GiaBan;

            try
            {
                // 1. Tạo đơn hàng
                db.TaoDonHang(Session.User.Id, total, txtAddress.Text + " - SĐT: " + txtPhone.Text, Session.Cart);

                // 2. Xóa sạch giỏ trong DB
                db.XoaSachGioDB(Session.User.Id);

                MessageBox.Show("Đặt hàng thành công! Cảm ơn bạn.");
                Session.Cart.Clear();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}