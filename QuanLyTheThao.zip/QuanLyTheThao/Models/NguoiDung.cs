﻿namespace QuanLyTheThao.Models
{
    public class NguoiDung
    {
        public int Id { get; set; }
        public string TaiKhoan { get; set; }
        public string MatKhau { get; set; } // Đã thêm dòng này để fix lỗi
        public string HoTen { get; set; }
        public string VaiTro { get; set; } // 'Admin' hoặc 'User'
        public string DiaChi { get; set; }
        public string SoDienThoai { get; set; }
    }
}