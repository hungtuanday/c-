﻿namespace QuanLyTheThao.Models
{
    public class SanPham
    {
        public int MaSP { get; set; }
        public string TenSP { get; set; }
        public int MaDM { get; set; }
        public string TenDM { get; set; }
        public decimal GiaBan { get; set; }
        public int SoLuongTon { get; set; }
        public string MoTa { get; set; }
        public string HinhAnh { get; set; }
    }
}