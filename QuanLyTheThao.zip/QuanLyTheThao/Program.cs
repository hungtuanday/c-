﻿using System;
using System.Windows.Forms;
using QuanLyTheThao.Forms; // Nhớ dòng này để nhận diện được các Form

namespace QuanLyTheThao
{
    internal static class Program
    {
        /// <summary>
        /// Điểm bắt đầu chính của ứng dụng.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Chạy Form Đăng Nhập đầu tiên
            Application.Run(new frmLogin());
        }
    }
}