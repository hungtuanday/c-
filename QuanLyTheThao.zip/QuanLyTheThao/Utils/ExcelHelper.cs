﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace QuanLyTheThao.Utils
{
    public static class ExcelHelper
    {
        public static void ExportToExcel(DataGridView dgv, string fileName)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "CSV (*.csv)|*.csv";
                sfd.FileName = fileName + "_" + DateTime.Now.ToString("ddMMyyyy_HHmm") + ".csv";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                    {
                        // Header
                        for (int i = 0; i < dgv.Columns.Count; i++)
                        {
                            sw.Write(dgv.Columns[i].HeaderText);
                            if (i < dgv.Columns.Count - 1) sw.Write(",");
                        }
                        sw.WriteLine();

                        // Rows
                        foreach (DataGridViewRow row in dgv.Rows)
                        {
                            if (row.IsNewRow) continue;
                            for (int i = 0; i < dgv.Columns.Count; i++)
                            {
                                string val = row.Cells[i].Value?.ToString() ?? "";
                                // Xử lý nếu dữ liệu có dấu phẩy -> bao ngoặc kép
                                if (val.Contains(",")) val = $"\"{val}\"";
                                sw.Write(val);
                                if (i < dgv.Columns.Count - 1) sw.Write(",");
                            }
                            sw.WriteLine();
                        }
                    }
                    MessageBox.Show("Xuất Excel thành công!\n" + sfd.FileName);
                    try { System.Diagnostics.Process.Start(sfd.FileName); } catch { }
                }
            }
            catch (Exception ex) { MessageBox.Show("Lỗi: " + ex.Message); }
        }
    }
}