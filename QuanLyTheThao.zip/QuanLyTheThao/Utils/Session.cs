﻿using System.Collections.Generic;
using QuanLyTheThao.Models;

namespace QuanLyTheThao.Utils
{
    public static class Session
    {
        public static NguoiDung User = null;
        // Thêm biến này để lưu giỏ hàng toàn cục
        public static List<SanPham> Cart = new List<SanPham>();
    }
}